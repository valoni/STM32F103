#include "tsc2046_functions.cpp"
#include "tsc2046_driver.cpp"
